# Here is the starting point for your Assignment 02 definitions. Add the 
# appropriate comment header as defined in the code formatting guidelines

# Here is the starting point for your Assignment 03 definitions. Add the 
# appropriate comment header as defined in the code formatting guidelines

/*
 *  Here is the starting point for your Assignment 02 includes. Add the
 *  appropriate comment header as defined in the code formatting guidelines.
 */

#ifndef A2_H
#define A2_H

/* add function prototypes */

#endif

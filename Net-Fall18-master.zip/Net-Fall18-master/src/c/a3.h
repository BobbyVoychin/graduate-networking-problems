/*
 *  Here is the starting point for your Assignment 03 includes. Add the
 *  appropriate comment header as defined in the code formatting guidelines.
 */

#ifndef A3_H
#define A3_H

/* add function prototypes */

#endif

/*
 *  Here is the starting point for your Assignment 04 includes. Add the
 *  appropriate comment header as defined in the code formatting guidelines.
 */

#ifndef A4_H
#define A4_H

/* add function prototypes */

#endif
